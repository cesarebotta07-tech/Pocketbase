import './style.css'

const API = "http://127.0.0.1:8090/api/collections/compito/records"

let markers = []

async function loadMarkers() {
  try {
    clearMarkers()

    const res = await fetch(API)
    if (!res.ok) throw new Error("Errore nel recupero dei dati")

    const data = await res.json()

    data.items.forEach(item => {
      if (item.lat && item.lng) {
        const marker = L.marker([item.lat, item.lng])
          .addTo(map)
          .bindPopup(item.titolo || "Senza titolo")

        markers.push(marker)
      }
    })
  } catch (error) {
    console.error(error)
    alert("Errore nel caricamento dei marker")
  }
}

function clearMarkers() {
  markers.forEach(m => map.removeLayer(m))
  markers = []
}

var map = L.map('map').setView([51.505, -0.09], 13)

L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
  maxZoom: 19,
  attribution: '&copy; OpenStreetMap'
}).addTo(map)

loadMarkers()

map.on("click", async (event) => {
  const { lat, lng } = event.latlng

  const titolo = prompt("Inserisci il titolo del marker:", "Nuovo marker")
  if (!titolo) return

  L.popup()
    .setLatLng([lat, lng])
    .setContent("Salvando marker...")
    .openOn(map)

  try {
    const res = await fetch(API, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ titolo, lat, lng })
    })

    if (!res.ok) throw new Error("Errore durante il salvataggio")

    await res.json()

    loadMarkers()
  } catch (error) {
    console.error(error)
    alert("Errore durante il salvataggio del marker")
  }
})

const postTest = document.getElementById("postTest")

postTest.onclick = async () => {
  try {
    await fetch(API, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ titolo: "prova debug" })
    })
    alert("Record di test inserito!")
    loadMarkers()
  } catch (e) {
    alert("Errore nel test POST")
  }
}
